<template>
  <div>
    <div class="login_form col-lg-4 align-content-center">
      <h2>注册</h2>
      <h6>用户名：</h6>
      <input type="text"  class=""  placeholder="用户名" v-model="userName"><br>
      <h6>密码：</h6>
      <input type="password"  class=""  placeholder="密码" v-model="password">
      <h6>确认密码：</h6>
      <input type="password"  class=""  placeholder="确认密码" v-model="password_com">
      <form action="" method="post">
        您的电影偏好？<br>
        <input type="checkbox" v-model="movietype" value="爱情">爱情
        <input type="checkbox" v-model="movietype" value="喜剧">喜剧
        <input type="checkbox" v-model="movietype" value="动画">动画
        <input type="checkbox" v-model="movietype" value="剧情">剧情
        <input type="checkbox" v-model="movietype" value="恐怖">恐怖<br>
        <input type="checkbox" v-model="movietype" value="惊悚">惊悚
        <input type="checkbox" v-model="movietype" value="科幻">科幻
        <input type="checkbox" v-model="movietype" value="动作">动作
        <input type="checkbox" v-model="movietype" value="悬疑">悬疑
        <input type="checkbox" v-model="movietype" value="犯罪">犯罪<br>
        <input type="checkbox" v-model="movietype" value="冒险">冒险
        <input type="checkbox" v-model="movietype" value="战争">战争
        <input type="checkbox" v-model="movietype" value="奇幻">奇幻
        <input type="checkbox" v-model="movietype" value="运动">运动
        <input type="checkbox" v-model="movietype" value="家庭">家庭<br>
        <input type="checkbox" v-model="movietype" value="古装">古装
        <input type="checkbox" v-model="movietype" value="武侠">武侠
        <input type="checkbox" v-model="movietype" value="西部">西部
        <input type="checkbox" v-model="movietype" value="历史">历史
        <input type="checkbox" v-model="movietype" value="传记">传记<br>
        <input type="checkbox" v-model="movietype" value="歌舞">歌舞
        <input type="checkbox" v-model="movietype" value="黑色电影">黑色电影
        <input type="checkbox" v-model="movietype" value="短片">短片
        <input type="checkbox" v-model="movietype" value="纪录片">记录片<br>
        <input type="checkbox" v-model="movietype" value="其他">其他
      </form>
      <el-button class="login_btn" @click.native="regist" type="primary" round :loading="isBtnLoading">注册</el-button>
    </div>
  </div>
</template>

<script>
  //  import { userLogin } from '../../api/api';

  export default {
    data() {
      return {
        userName: '',
        password: '',
        password_com:'',
        userLike:'',
        isBtnLoading: false,
        movietype:[],
        count:''
      }
    },
    created () {
      if(JSON.parse( localStorage.getItem('user')) && JSON.parse( localStorage.getItem('user')).userName){
        this.userName = JSON.parse( localStorage.getItem('user')).userName;
        this.password = JSON.parse( localStorage.getItem('user')).password;
        this.password_com=JSON.parse( localStorage.getItem('user')).password_com;
      }
    },
    computed: {
      btnText() {
        if (this.isBtnLoading) return '注册中...';
        return '注册';
      }
    },
    methods: {
      regist() {
        const TIME_COUNT = 3;
        if (!this.userName) {
          this.$message.error('请输入用户名');
          return;
        }
        if (!this.password) {
          this.$message.error('请输入密码');
          return;
        }
        if (!this.password_com) {
          this.$message.error('请输入密码');
          return;
        }
        if(this.password!=this.password_com){
          this.$message.error('密码不匹配')
          return;
        }
        this.$http.post('后端接收地址',{user:this.userName,password:this.password,like:this.movietype},{emulateJSON:true});
        this.$message.success('注册成功,3秒后跳转');
        if(!this.timer){
          this.count = TIME_COUNT;
        }
        this.show = false;
        this.timer = setInterval(()=>{
          if(this.count > 0 && this.count <= TIME_COUNT){
            this.count--;
          } else {
            this.show = true;
            clearInterval(this.timer);
            this.timer = null;
            this.$router.push({path: '/login'});
            }
          },1000)
      }
    }
  }
</script>

<style scoped>

</style>
