<template>
<!--  <div class="grid-950 clearfix">-->
<!--      <article class="container">-->
<!--        <div class="two-list" v-loading="this.loadingMoving">-->
<!--          <ul class="clearfix">-->
<!--            <li class="item" v-for="(item, index) in this.upcoming.subjects" :key="index">-->
<!--              <a class="thumb" @click="showDetail(item.id)">-->
<!--                  <img class="movieImg" :src="item.images.large">-->
<!--              </a>-->
<!--              <div class="intro">-->
<!--                  <h3>-->
<!--                      <a v-bind:href="item.alt" class="">{{item.title}}</a>-->
<!--                      <span class="icon"></span>-->
<!--                  </h3>-->
<!--                  <ul>-->
<!--                          <li class="dt"><em v-for="it in item.genres">{{it}}/</em></li>-->
<!--                  </ul>-->
<!--              </div>-->
<!--            </li>-->
<!--          </ul>-->
<!--          <div class="load-more">-->
<!--            <el-button type="text" @click="moredata" v-show="!pageload && !nodata">加载更多</el-button>-->
<!--            <el-button type="text" v-show="pageload">加载中...</el-button>-->
<!--            <el-button type="text" v-show="nodata">没有更多了</el-button>-->
<!--          </div>-->
<!--        </div>-->
<!--      </article>-->
<!--  </div>-->
  <div class="container">
    <input type="button" value="喜剧" onclick="">
    <searchTag v-for="(subject, index) in Tagsort.subjects" :subject="subject" :key='index'></searchTag>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import searchTag from './common/searchTag'
  export default{
    data () {
      return {
      }
    },
    mounted () {
      this.$store.dispatch('getTagList')
    },
    components: {
      searchTag
    },
    mounted() {
      if (this.searchText === "") {
        let searchText = this.$route.query.searchText
        this.$store.commit('SEARCH_TEXT', {searchText: "喜剧"})
        this.$store.dispatch('getTagList')
      }
    },
    computed: {
      ...mapGetters([
        'searchText',
        'searchList',
        'searchLoading'
      ])
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->

<style rel="stylesheet/less" lang="less">
@import '../../style/base.less';
.container{
  float: left;
  width: 590px;
}
.right-side{
  float: right;
  width: 310px;
}
.two-list{
  min-height: 500px;
}
.tit{
    margin-top: 20px;
  h1{
    display: inline-block;
    width: 90px;
    font-size: 20px;
    color: #000;
  }
  .locat{
    position: relative;
    display: inline-block;
  }
}
.locat{
  .cities-list{
    position: absolute;
    left: 0;
    top: 18px;
    padding: 10px;
    background: #fff;
    z-index: 999;
    border: 1px solid #ccc;
    span{
      display: block;
    }
  }
}
.item{
  position: relative;
  float: left;
  padding: 20px 0 20px 120px;
  width: 173px;
  height: 140px;
  border-bottom: 1px dashed #ccc;
}
.item .thumb{
  position: absolute;
  left: 0;
  width: 100px;
  height: 140px;
  overflow: hidden;
  img{
    width: 100%;
    height: 140px;
  }
}
.tab-hd{
  vertical-align: bottom;
  li{
    margin: 0 5px;
    float: left;
  }
  .on{
    background-color: #69c;
    color: #fff;
    padding: 0 10px;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    border-radius: 2px;
  }
}
.hd{
  padding: 10px 0;
  border-bottom: 1px dashed #ccc;
  h2,.tab-hd{
    display: inline-block;
  }
}
.load-more{
  text-align: center;
}
</style>
