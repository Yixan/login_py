<template>
  <div class="content-container">
    <MoviesTag :data="this.movingData"></MoviesTag>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import MoviesTag from './common/moviesTag.vue'
export default {
  name: 'movie',
  data () {
    return {
      citys: [
        {
          name: '北京'
        },
        {
          name: '上海'
        },
        {
          name: '广州'
        },
        {
          name: '深圳'
        },
        {
          name: '杭州'
        }
      ]
    }
  },
  mounted () {
    this.$store.commit('MOVING_LOADING', {loading: true})
    this.$store.dispatch('getMoving')
  },
  methods: {
    changeCity(command) {
      this.$store.commit('MOVING_LOADING', {loading: true})
      this.$store.commit('MOVIE_CITY', {city: command})
      this.$store.dispatch('getMoving')
    }
  },
  components: {
    MoviesTag
  },
  computed: {
    ...mapGetters([
      'movingData',
      'city'
    ])
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
@import "../../style/color";
@import "../../style/base";
.moving {
  margin-bottom: 20px;
  p {
    color: red;
  }
  .tit {
    width: 950px;
    margin: 0 auto;
    margin-top: 20px;
    h1 {
      display: inline-block;
      width: 126px;
      font-size: 20px;
      color: #000;
    }
    .locat {
      position: relative;
      display: inline-block;
    }
    .hd{
      border: none;
      margin: 15px 0;
    }
  }
  .content-container{
    width: 950px;
    overflow: hidden;
    margin: 10px auto;
    padding-bottom: 20px;
    .aside{
      width: 300px;
      float: right;
      padding-top: 20px;
      img{
        margin: 20px 0;
      }
      .aside-top{
        background-color: #f2f7f6;
        border-radius: 4px;
        padding: 6px 0 6px 18px;
        li{
          color: @doubanColor;
          margin: 10px 0;
        }
        h2{
          color:#072;
          font-size: 15px;
          margin-bottom: 12px;
        }
      }
    }
  }
}
</style>
