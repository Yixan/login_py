import Vue from 'vue'
import Router from 'vue-router'
import Movie from '@/components/Movie'
import Tagsort from '@/components/Tagsort'
import Top250 from '@/components/top250'
import MoviesDetail from '@/components/common/moviesDetail'
import SearchList from '@/components/searchList'
import Login from '@/components/Login'
import 'bootstrap/dist/css/bootstrap.min.css';
import Regist from "../components/Regist";

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'movie',
      component: Movie
    },
    {
      path: '/tagsort' ,
      name: 'tagsort',
      component: Tagsort
    },
    {
      path: '/top250' ,
      name: 'top250',
      component: Top250
    },
    {
      path: '/moviesDetail' ,
      name: 'moviesDetail',
      component: MoviesDetail
    },
    {
      path: '/search' ,
      name: 'search',
      component: SearchList
    },
    {
      path:'/login',
      name:'login',
      component:Login
    },
    {
      path:'/regist',
      name:'regist',
      component:Regist
    }
  ]
})
